﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfLab
{
    /// <summary>
    /// Interaction logic for BindLab1.xaml
    /// </summary>
    public partial class BindLab1 : Window
    {
        public BindLab1()
        {
            InitializeComponent();
            CreateBinding();
        }

        private void ScrollBar1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            this.Label1.Content = ((int)this.ScrollBar1.Value).ToString();
            //this.Label1.Content = e.NewValue.ToString();
        }

        private void CreateBinding()
        {
            var binding = new Binding();
            binding.Source = this.ScrollBar3; //來源物件
            binding.Path = new PropertyPath("Value");
            binding.Mode = BindingMode.TwoWay; //雙方繫結
            this.Label3.SetBinding(ContentProperty, binding); //目標物件
        }
    }
}
