﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfLab.Models;

namespace WpfLab
{
    /// <summary>
    /// Interaction logic for PassDataWindow1.xaml
    /// </summary>
    public partial class PassDataWindow1 : Window
    {
        public PassDataWindow1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //  var win = new PassDataWindow2(this.TextBox1.Text);

            //var passData = new Person()
            //{
            //    Name = "ian",
            //    Email = "ian@mail.com"
            //};
            ////傳遞物件
            //var win = new PassDataWindow2(passData);


            var win = new PassDataWindow2();
            //win.PassData = this.TextBox1.Text;
            win.DataContext = this.TextBox1.Text;

            win.ShowDialog();
        }
    }
}
