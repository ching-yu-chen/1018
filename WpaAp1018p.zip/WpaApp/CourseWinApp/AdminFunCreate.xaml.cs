﻿using CourseLibrary.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseWinApp
{
    /// <summary>
    /// Interaction logic for AdminFunCreate.xaml
    /// </summary>
    public partial class AdminFunCreate : Window
    {
        private readonly string _dbConnStr;
        private AdminUserInfo _adminUserInfo;
        public AdminFunCreate()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
            _adminUserInfo = new AdminUserInfo();
            this.DataContext = _adminUserInfo;
        }

        /// <summary>
        /// 取消按鈕 - 關閉視窗
        /// </summary>
        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void CreateBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
