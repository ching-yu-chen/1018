﻿using CourseLibrary.DataModels;
using CourseLibrary.DataService;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CourseWinApp
{
    /// <summary>
    /// Interaction logic for AdminFunPage.xaml
    /// </summary>
    public partial class AdminFunPage : Page
    {
        private readonly string _dbConnStr;
        private ObservableCollection<AdminUserInfo> _adminUserList { get; set; }

        public AdminFunPage()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
        }

        private void Query()
        {
            var service = new AdminUserRepository(_dbConnStr);
            _adminUserList = service.Query(
                new AdminUserQueryParameter() { UserName = this.UserName.Text, Email = this.Email.Text }
                );
            this.UserList.ItemsSource = _adminUserList;
        }


        private void QueryButton_Click(object sender, RoutedEventArgs e)
        {
            Query();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            var create = new AdminFunCreate();
            create.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            create.ShowDialog();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
