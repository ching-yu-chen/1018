﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseWinApp
{
    /// <summary>
    /// Interaction logic for MenuWindow.xaml
    /// </summary>
    public partial class MenuWindow : Window
    {
        public MenuWindow()
        {
            InitializeComponent();

            // 顯示登入使用者名稱
            var app = (App)Application.Current;
            if (app.CurrentUser != null)
            {
                User.Text = app.CurrentUser.UserName;
            }
        }

        /// <summary>
        /// 管理員資料管理
        /// </summary>
        private void AdminFun_Click(object sender, RoutedEventArgs e)
        {
            // 載入管理員資料管理頁面到 Frame
            FunFrame.Navigate(new AdminFunPage());
        }

        /// <summary>
        /// 學員資料管理
        /// </summary>
        private void StuFun_Click(object sender, RoutedEventArgs e)
        {
            // TODO: 載入學員資料管理頁面
            MessageBox.Show("學員資料管理功能開發中...", "訊息", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// 講師資料管理
        /// </summary>
        private void TeaFun_Click(object sender, RoutedEventArgs e)
        {
            // TODO: 載入講師資料管理頁面
            MessageBox.Show("講師資料管理功能開發中...", "訊息", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// 課程資料管理
        /// </summary>
        private void CourseFun_Click(object sender, RoutedEventArgs e)
        {
            // TODO: 載入課程資料管理頁面
            MessageBox.Show("課程資料管理功能開發中...", "訊息", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// 開課資料管理
        /// </summary>
        private void CourseScheduleFun_Click(object sender, RoutedEventArgs e)
        {
            // TODO: 載入開課資料管理頁面
            MessageBox.Show("開課資料管理功能開發中...", "訊息", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// 變更密碼功能
        /// </summary>
        private void PwdFun_Click(object sender, RoutedEventArgs e)
        {
            // 載入變更密碼頁面到 Frame
            FunFrame.Navigate(new PwdFunPage());
        }

        /// <summary>
        /// 登出功能
        /// </summary>
        private void LogoutFun_Click(object sender, RoutedEventArgs e)
        {
            // 確認是否要登出
            var result = MessageBox.Show(
                "確定要登出嗎？",
                "登出確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                // 清除目前使用者資訊
                var app = (App)Application.Current;
                app.CurrentUser = null;

                // 開啟登入視窗
                var loginWindow = new MainWindow();
                loginWindow.Show();

                // 關閉目前視窗
                this.Close();
            }
        }
    }
}
