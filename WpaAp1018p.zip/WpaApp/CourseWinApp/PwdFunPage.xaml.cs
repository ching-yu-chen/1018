﻿using CourseLibrary.DataService;
using CourseWinApp.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CourseWinApp
{
    /// <summary>
    /// Interaction logic for PwdFunPage.xaml
    /// </summary>
    public partial class PwdFunPage : Page
    {
        private string _dbConnStr;
        public PwdFunPage()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
        }
        private void PwdChgBtn_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(this.OldPwd.Password) ||
               string.IsNullOrEmpty(this.NewPwd.Password) ||
               string.IsNullOrEmpty(this.ConfirmPwd.Password))
            {
                MessageBox.Show("所有欄位必填", "訊息", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // 新密碼與確認密碼不一致
            if (this.NewPwd.Password != this.ConfirmPwd.Password)
            {
                MessageBox.Show("新密碼不一致", "訊息", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            //檢查原始密碼
            var admin = ((App)Application.Current).CurrentUser;
            var oldHashPwd = LoginHelper.PwdHash(this.OldPwd.Password, admin.Id.ToString());
            if (oldHashPwd != admin.Password)
            {
                MessageBox.Show("原始密碼錯誤", "訊息", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            //更新密碼to db
            var newHashPwd = LoginHelper.PwdHash(this.NewPwd.Password, admin.Id.ToString());
            var dbService = new AdminUserRepository(_dbConnStr);
            dbService.UpdatePwd(admin.Id, newHashPwd);

            // 顯示密碼變更成功訊息
            MessageBox.Show("密碼變更成功，請重新登入。", "訊息", MessageBoxButton.OK, MessageBoxImage.Information);

            //登出
            ((App)Application.Current).CurrentUser = null;
            var login = new MainWindow();
            login.Show();

            //關閉目前視窗
            Window currentWindow = Window.GetWindow(this);
            if (currentWindow != null)
            {
                currentWindow.Close();
            }
        }
    }
}
